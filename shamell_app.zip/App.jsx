[Paste of the current React component code will go here if needed]
